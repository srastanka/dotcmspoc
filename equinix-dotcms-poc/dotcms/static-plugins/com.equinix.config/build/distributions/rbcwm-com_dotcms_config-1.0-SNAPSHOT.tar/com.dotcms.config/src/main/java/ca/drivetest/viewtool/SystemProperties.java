package ca.drivetest.viewtool;

public class SystemProperties {
    public static String getProperty(String key) {
        return System.getProperty(key);
    }
}

