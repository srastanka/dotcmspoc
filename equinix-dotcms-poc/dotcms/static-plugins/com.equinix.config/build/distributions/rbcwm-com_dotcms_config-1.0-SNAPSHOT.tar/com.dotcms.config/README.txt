This plugin is the proper place to override 
the dotCMS default configuration.  By adding 
files under the ./conf folder, you can modify 
your dotCMS's behavior. 

See the example

	$DOTCMS_ROOT/docs/examples/plugins/hello.world 

for a complete demonstration of what you can 
do with plugins
